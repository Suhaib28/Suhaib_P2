
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <climits>
#include <iomanip>
#include <cmath>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

int n, m;
int adj[100][100];

void dijkstra(int start) {
    int dist[100];
    bool visited[100];
    for (int i = 0; i < n; i++) {
        dist[i] = INT_MAX;
        visited[i] = false;
    }
    dist[start] = 0;
    for (int count = 0; count < n - 1; count++) {
        int minDist = INT_MAX, u = -1;
        for (int v = 0; v < n; v++) {
            if (!visited[v] && dist[v] <= minDist) {
                minDist = dist[v];
                u = v;
            }
        }
        if (u == -1) break;
        visited[u] = true;
        for (int v = 0; v < n; v++) {
            if (!visited[v] && adj[u][v] && dist[u] != INT_MAX && dist[u] + adj[u][v] < dist[v]) {
                dist[v] = dist[u] + adj[u][v];
            }
        }
    }
    cout << "		Single source shortest path lengths from node " << start + 1 << endl;
    for (int i = 0; i < n; i++) {
        cout << "  " << i + 1 << ": " << dist[i] << endl;
    }
}

int main() {
    for (int i = 0; i < 100; i++) {
        for (int j = 0; j < 100; j++) {
            adj[i][j] = 0;
        }
    }
    cin >> n >> m;
    int u, v;
    for (int i = 0; i < m; i++) {
        cin >> u >> v;
        adj[u-1][v-1] = 1;
        adj[v-1][u-1] = 1;
    }
    cout << "		The adjacency matrix of G:" << endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << adj[i][j];
            if (j != n - 1) cout << " ";
        }
        cout << endl;
    }
    int oddVertices[100];
    int oddCount = 0;
    for (int i = 0; i < n; i++) {
        int degree = 0;
        for (int j = 0; j < n; j++) {
            degree += adj[i][j];
        }
        if (degree % 2 != 0) {
            oddVertices[oddCount++] = i;
        }
    }
    cout << endl << "		The odd degree vertices in G:" << endl;
    cout << "O = {";
    for (int i = 0; i < oddCount; i++) {
        cout << " " << oddVertices[i]+1;
    }
    cout << " }" << endl;
    for (int i = 0; i < oddCount; i++) {
        dijkstra(oddVertices[i]);
    }
    return 0;
}
